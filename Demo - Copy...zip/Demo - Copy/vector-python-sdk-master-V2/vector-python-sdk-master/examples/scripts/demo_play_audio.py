#!/usr/bin/env python3



"""Play audio files through Vector's speaker.
"""

import anki_vector



def main():
    args = anki_vector.util.parse_command_args()
    with anki_vector.Robot(args.serial) as robot:
        
        #
        # Paste these two wav files next to this tutorial to play sounds.
        robot.audio.stream_wav_file("vector_bell_whistle.wav", 75)
        robot.audio.stream_wav_file("vector_alert.wav", 75)
        robot.audio.stream_wav_file("Too Much Dip On Ya Chip - QuickSounds.com.mp3", 100)

if __name__ == "__main__":
    main()

