We accept contributions from 3rd parties as long as you first complete an individual CLA (Contributor License Agreement):

http://go.anki.com/individual-cla

If your employer(s) have rights to intellectual property that you create, and that includes your contributions, then we also require a separate Corporate CLA from them:

http://go.anki.com/corporate-cla

Please also review our: [Code Style Guide](CODESTYLE.md)
