:orphan:

Protobuf Documentation
======================

**PLEASE NOTE:  The Vector Python SDK is supported by Anki. Using protocol buffer messages directly is not supported. The proto messages are subject to change without warning. Use with caution.**

.. raw:: html
   :file: proto.html

----

`Terms and Conditions <https://www.anki.com/en-us/company/terms-and-conditions>`_ and `Privacy Policy <https://www.anki.com/en-us/company/privacy>`_

`Click here to return to the Anki Developer website. <https://developer.anki.com>`_