#########
Downloads
#########

------------
SDK Examples
------------

Download Python example scripts that use the Vector SDK.

`macOS/Linux SDK Examples <https://sdk-resources.anki.com/vector/0.6.0/anki_vector_sdk_examples_0.6.0.tar.gz>`_

`Windows SDK Examples <https://sdk-resources.anki.com/vector/0.6.0/anki_vector_sdk_examples_0.6.0.tar.gz>`_

------
GitHub
------

Clone, fork, or report issues on the `GitHub vector-python-sdk repository <https://github.com/ikkez/vector-python-sdk>`_.

----

`Terms and Conditions <https://www.anki.com/en-us/company/terms-and-conditions>`_ and `Privacy Policy <https://www.anki.com/en-us/company/privacy>`_

`Click here to return to the Anki Developer website. <https://developer.anki.com>`_
