For the demo the in the Vector master file 
You can file the scripts in side the scripts folder loacted in 
Vector\Final Devy\Demo_presentation\Demo - Copy\vector-python-sdk-master-V2\vector-python-sdk-master\examples\scripts
inside this folder will be the demo script that show an attack on Vector configuration file 
along with other codes That I made for vector using the SDK

Sound files that Vector can play are loacted 
Vector\Final Devy\Demo_presentation\Demo - Copy\vector-python-sdk-master-V2\vector-python-sdk-master\examples\Sound 

images that Vector can display on screen ar loacted
Vector\Final Devy\Demo_presentation\Demo - Copy\vector-python-sdk-master-V2\vector-python-sdk-master\examples\face_images
However, since the images size must be 184x96 in jpg format most images will have to be moded